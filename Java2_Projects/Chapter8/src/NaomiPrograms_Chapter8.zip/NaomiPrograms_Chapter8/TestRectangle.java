
public class TestRectangle {

	public static void main(String[] args) {
		Rectangle rectangle1 = new Rectangle(4.0, 40.0);
		Rectangle rectangle2 = new Rectangle(3.5, 35.9);
		
		System.out.println("Rectangle1 has the following information: ");
		rectangle1.printRectangle();
		System.out.println();
		System.out.println("Rectangle2 has the following information: ");
		rectangle2.printRectangle();
	}

}
