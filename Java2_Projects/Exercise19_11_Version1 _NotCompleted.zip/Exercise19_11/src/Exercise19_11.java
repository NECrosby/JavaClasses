import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

// Naomi Crosby - Java II - Chapter 19 Assignment 
// Exercise 19.11 Page 673 - Due 9/24/2012
// Started 	2:00pm -  3:00pm	9/17/2012
//			9:00am - 			9/26/2012

/* *********************************************************************************\	
|  	Hints:																			|
|		Under the D2L content, there�s a file named Exercise19_11.dat that you 		|
|		can use for splitting (keep in mind however that because it is a binary		|
|		file, you will not be able to verify the contents of the split). Using a	| 
|		larger file however may prove more beneficial.								| 
\***********************************************************************************/

@SuppressWarnings("serial")
public class Exercise19_11 extends JFrame {
	// Variables used for GUI build
	static JTextField jtfSourceFile = new JTextField(10);
	JTextField jtfNumberOfTargetFile = new JTextField(10);
	JButton jbtBrowse = new JButton("Browse");
	static JButton jbtStart = new JButton("Start");
	// String Builder here
	JTextArea jtaDescription = new JTextArea("If you split a file named [_____.txt] into [_] smaller files, the [_] smaller files are [_____.txt] + [_], [_____.txt] + [_], and [_____.txt] + [_].");

	// Program data variables
	static String strSourceFileName = "Exercise19_11.dat";  //jtfSourceFile.getText();
	static String strTargetFile = "temp.dat";
	Integer intNumberOfTargetFile = -1;
	Double dblNumberOfBytesInSourceFile = 0.0;

	// Building the GUI
	public Exercise19_11(){
		// Adding description of the program
		jtaDescription.setRows(3);
		jtaDescription.setEditable(false);
		jtaDescription.setLineWrap(true);
		jtaDescription.setWrapStyleWord(true);
		add(jtaDescription, BorderLayout.NORTH);

		// Creating and setting up user input panel
		JPanel p1 = new JPanel(new FlowLayout(FlowLayout.LEFT));
		p1.add(new JLabel("Enter or choose a file: "));
		p1.add(jtfSourceFile);
		p1.add(jbtBrowse);
		p1.add(new JLabel("Specify the number of smaller files: "));
		p1.add(jtfNumberOfTargetFile);
		add(p1, BorderLayout.CENTER);

		// Create the start button
		add(jbtStart, BorderLayout.SOUTH);
	}

	public static void main(String[] args) throws IOException {
		Exercise19_11 frame = new Exercise19_11();
		frame.setTitle("Exercise 19.11: Split a File");
		frame.setSize(350, 200);
		frame.setLocationRelativeTo(null);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);

		// Check to see if source file exists  
		// page 329 - Chapter  9 Strings & Text I/O
		// page 661 - Chapter 19 Binary I/O
		final File sourceFile = new File(strSourceFileName);
		if (!sourceFile.exists()){
			System.out.println("Source file " + strSourceFileName + " does not exist");
			// Show this is a dialog warning box

		} else {    // Debugging only
			System.out.println("Source file found - " + strSourceFileName);
		}
		
		// Check to see if the target file exists (testing it with 1 file first, before attempting to split)
		final File targetFile = new File(strTargetFile);
		if (targetFile.exists()){
			System.out.println("Target file " + strTargetFile + " already exists");
			// Show this is a dialog warning box

		} else {    // Debugging only
			System.out.println("Target File: " + strTargetFile + " was deleted - READY TO COPY ");
		}
		
		jbtStart.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				try {
					// Creating an input stream
					BufferedInputStream input = new BufferedInputStream(new FileInputStream(sourceFile));
					System.out.println("Buffered FileInputStream created successfully"); // Debugging only
					// Creating an output stream
					BufferedOutputStream output = new BufferedOutputStream(new FileOutputStream(targetFile));
					System.out.println("Buffered FileOutputStream created successfully"); // Debugging only
					
					// Read info from input and write it to output "Copying Data"
					int r; int numberOfBytesCopied = 0;
					while ( (r = input.read()) != -1) {
						output.write((byte) r);
						numberOfBytesCopied++;
					}
					
					// Close streams
					input.close();
					output.close();
					System.out.println("Buffered File Streams CLOSED"); // Debugging only
					
					// ---------------- Debugging purposes only ---------------
					// --------- Display Info acquired during copying --------- 
					System.out.println(numberOfBytesCopied + " bytes copied"); // SysO then Ctrl Space - Quick key enter
					if (targetFile.exists()){
						System.out.println("Copy Successful: Target file " + strTargetFile + " does exist");
						// Show this is a dialog warning box

					}
					targetFile.delete();
					System.out.println("*** WARNING: NOW Target file: " + strTargetFile + " has been deleted");
					// ^^^ ---------- Debugging purpose code above -------  ^^^
					
				} catch (FileNotFoundException e1) {
					e1.printStackTrace();
				} catch (IOException e2) {
					e2.printStackTrace();
				}
			}
		});
	}
}
