// Naomi Crosby - Java II - Chapter 18 Assignment 
// Exercise 18.21 Page 645 - Due 9/17/2012
// Started 	9/15/2012	12:20am-12:40am
//			9/15		1:00am-1:15am
//			9/15		10:45pm-12:15am
//			9/17		8:40am		

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Calendar;
import java.util.GregorianCalendar;

import javax.swing.JApplet;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

/* *********************************************************************************\	
|  	Hints:																			|
|		Have a timer. In the event handler, display the hour, minute and second		| 
|		(see the get method for the Gregorian calendar class). If the alarm is 		|
|		turned on, check if the values in the alarm text fields match the clock		| 
|		time (you would probably store the values entered in the text fields		| 
|		into variables accessible to the classes for the program). If so, 			|
|		display a sound (something that sounds like an alarm). You could create		| 
|		a new frame (i.e. a new object) in your listener for the Set Alarm			|
|		button. Set that frame to be visible. In your listeners for the Ok and 		|
|		Cancel buttons for that frame, set the frame to be invisible.				|
|																					|
|		Your program should work as a standalone program or as an applet.			|
|																					|
|		In setting the alarm, be sure to validate that proper values are entered	|
|		(i.e. hours: 0 -23, minutes and seconds: 0 � 59)							|
\***********************************************************************************/

public class Exercise18_21 extends JApplet {
	// Getting calendar object - will need to convert Time to a string to display in the clock
	Calendar calendar = new GregorianCalendar();
	String strClockHour = Integer.toString(calendar.get(Calendar.HOUR));
	String strClockMinute = Integer.toString(calendar.get(Calendar.MINUTE));
	String strClockSecond = Integer.toString(calendar.get(Calendar.SECOND));
	
	// Frame 1 - components
	private JButton jbtSetAlarm = new JButton("Set Alarm");
	private JCheckBox jckAlarm = new JCheckBox("Alarm");
	private JLabel jlblClockHour = new JLabel(strClockHour);	
	private JLabel jlblClockMinute = new JLabel(strClockMinute);	
	private JLabel jlblClockSecond = new JLabel(strClockSecond);
	
	// Frame 2 - Declare a SetAlarm & Setup a new Frame to hold setAlarm
	private SetAlarm setAlarm = new SetAlarm();
	private JFrame alarmFrame = new JFrame("Set Alarm");	
			
	// This is the start of the applet
	public Exercise18_21 (){
		// Set up NORTH Panel
		JPanel p1 = new JPanel(new GridLayout(1, 3));	// North Panel
		p1.add(new JLabel("Hour", JLabel.CENTER));
		p1.add(new JLabel("Minute", JLabel.CENTER));
		p1.add(new JLabel("Second", JLabel.CENTER));
		add(p1, BorderLayout.NORTH);
		
		// Set up CENTER Panel
		JPanel p6 = new JPanel(new GridLayout(1, 3, 10, 0));	// Center Panel
		JPanel p3 = new JPanel(); 						// Hour panel within the Center panel
		jlblClockHour.setFont(new Font("SanSerif", Font.BOLD, 40));
		p3.setBackground(Color.WHITE);
		jlblClockHour.setHorizontalAlignment(SwingConstants.CENTER);
		jlblClockHour.setVerticalAlignment(SwingConstants.BOTTOM);
		p3.add(jlblClockHour);
		p6.add(p3);
		JPanel p4 = new JPanel(); 						// Minute panel within the Center panel
		jlblClockMinute.setFont(new Font("SanSerif", Font.BOLD, 40));
		p4.setBackground(Color.WHITE);
		jlblClockMinute.setHorizontalAlignment(SwingConstants.CENTER);
		jlblClockMinute.setVerticalAlignment(SwingConstants.BOTTOM);
		p4.add(jlblClockMinute);
		p6.add(p4);
		JPanel p5 = new JPanel(); 						// Second panel within the Center panel
		jlblClockSecond.setFont(new Font("SanSerif", Font.BOLD, 40));
		p5.setBackground(Color.WHITE);
		jlblClockSecond.setHorizontalAlignment(SwingConstants.CENTER);
		jlblClockSecond.setVerticalAlignment(SwingConstants.BOTTOM);
		p5.add(jlblClockSecond);
		p6.add(p5);
		add(p6, BorderLayout.CENTER);

		// Set up SOUTH Panel
		JPanel p2 = new JPanel(new FlowLayout());	// South Panel
		p2.add(jckAlarm);
		p2.add(jbtSetAlarm);
		add(p2, BorderLayout.SOUTH);
		
		// Register Listeners
		jbtSetAlarm.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				alarmFrame.setVisible(true);
			}
		});
		
		alarmFrame.add(setAlarm);
		alarmFrame.setSize(250, 200);
		alarmFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
					
	}

	// To make the Applet as a stand alone add a main method
	//
	// ADD TITLE when run as an Applet!!
	//
	public static void main(String[] args) {
		// Create a frame
		JFrame frame = new JFrame("Exercise 18.21: Alarm Clock");
		
		// Create an instance of the applet in the main method
		Exercise18_21 applet = new Exercise18_21();
		
		// Adding applet to the frame
		frame.add(applet);
		
		// setting frame preferences
		frame.setSize(500, 150);
		frame.setLocationRelativeTo(null);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}

}
